const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
let port = 8100;
app.use(bodyParser.urlencoded({limit:'50mb',extended:true}));
app.use(bodyParser.json({limit:'50mb',extended:true}));
app.use(cors())


require('./lib/route')(app);

app.listen(port,()=>{
    console.log("Server is started and running in the port " +port);
    console.log("Waiting for DB Connection.....");
});