import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../services/data-service';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(
    private dataService: DataService,
    public ref: ChangeDetectorRef,
    public router: Router
  ) { }

  productListArray: any[];
  imageAcceptTypes = "image/x-png,image/jpeg";
  @ViewChild('uploadFile', { static: false }) uploadFileElement: ElementRef;
  isListLoading: boolean = false;
  addBtnSpinner: boolean = false;
  showAddForm: boolean = false;
  currentPageNo: number = 1;

  searchField = new FormControl('');
  productForm = new FormGroup({
    ProductName: new FormControl('', Validators.required),
    ProductCode: new FormControl('', Validators.required),
    Category: new FormControl('', Validators.required),
    ProductImage: new FormControl('', Validators.required),
    ProductDescription: new FormControl('')
  });

  ngOnInit() {
    this.loadProductList();
  }

  //list all products with pagination
  loadProductList() {
    this.isListLoading = true;
    this.productListArray = [];
    this.ref.detectChanges();
    let prepareData: any = {
      page: this.currentPageNo
    }
    this.dataService.processRequest('getProductList', prepareData).then((dbResult: any) => {
      this.productListArray = dbResult.result;
      this.isListLoading = false;
      this.ref.detectChanges();
    });
  }

  //get search result
  doProductSearch() {
    if (this.searchField.valid) {
      this.isListLoading = true;
      this.dataService.processRequest('doProductSearch', { 'searchText': this.searchField.value }).then((dbResult: any) => {
        this.productListArray = dbResult.result;
        this.isListLoading = false;
        this.ref.detectChanges();
      });
    }
  }

  //adding new product
  addProduct() {
    if (this.productForm.valid) {
      this.dataService.processRequest('addProduct', this.productForm.value).then((result: any) => {
        console.log("result=addProduct=====", result);
        if (result.response) {
          alert("product Added Successfully");
          this.addBtnSpinner = false;
          this.productForm.reset();
          this.uploadFileElement.nativeElement.value = "";
          this.loadProductList();
          this.showAddForm = false;
          this.ref.detectChanges();
        }
        else {
          alert("Please try later!");
        }
      });
    }
    else {
      alert("Please check your Information!");
    }
  }

  //check and process for uploaded image
  processUploadedImage(uploadFile: any) {
    let files: any = uploadFile;
    if (files.length === 0) {
      alert("Something went wrong please choose image again.");
    }
    else {
      let fileType: string = files[0].type;
      let imgSize: number = files[0].size;
      let supportedFileType: string[] = ['image/png', 'image/jpeg'];
      //check image size less than 2 mb.
      if (imgSize <= 2000000) {
        
        this.productForm.get('ProductImage').setValidators(() => { return null });
        this.productForm.get('ProductImage').updateValueAndValidity({ onlySelf: true });

        if (!supportedFileType.includes(fileType)) {

          this.productForm.get('ProductImage').setValidators(() => { return { inValidType: true } });
          this.productForm.get('ProductImage').updateValueAndValidity({ onlySelf: true });

          this.uploadFileElement.nativeElement.value = "";
          this.productForm.patchValue({
            'ProductImage': ''
          });
          files = null;
          this.ref.detectChanges();
        }
        else {

          this.productForm.get('ProductImage').setValidators(() => { return null });
          this.productForm.get('ProductImage').updateValueAndValidity({ onlySelf: true });

          let reader: FileReader = new FileReader();
          reader.readAsDataURL(files[0]);
          reader.onload = (_event) => {
            this.productForm.patchValue({
              'ProductImage': reader.result
            });
          }
        }
      } else {
        this.uploadFileElement.nativeElement.value = "";
        this.productForm.get('ProductImage').setValidators(() => { return { inValidSize: true } });
        this.productForm.get('ProductImage').updateValueAndValidity({ onlySelf: true });
        this.productForm.patchValue({
          'ProductImage': ''
        });
        files = null;
        this.ref.detectChanges();
      }
    }
  }

  //checks unique value for fields
  checkUniqueValue(controlName: string) {
    this.productForm.get(controlName).setAsyncValidators(this.processValidator(controlName));
    this.productForm.get(controlName).updateValueAndValidity({ onlySelf: true });
  }

  //validator
  processValidator(fieldName: string) {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      return new Promise((resolve) => {
        let value: string = control.value;
        if (value) {
          let timeoutID = setTimeout(() => {
            let filter: any = {};
            filter[fieldName] = value;
            if (Object.keys(filter).length > 0) {
              let data = {
                filter: filter
              };
              this.dataService.processRequest('checkUnique', data).then((res) => {
                if (res.result.isUnique === false) {
                  resolve({ 'isNotUnique': true });
                } else {
                  resolve(null);
                }
              })
            }
            else {
              resolve(null);
            }
            clearTimeout(timeoutID);
          }, 2000);
        } else {
          resolve(null);
        }
      });
    }
  }

  //pagination for listing
  processPagination(page: any) {
    if (page === "pervious") {
      if (this.currentPageNo !== 1) {
        this.currentPageNo = this.currentPageNo - 1;
      }
    }
    else if (page === "next") {
      this.currentPageNo++;
    }
    else {
      this.currentPageNo = page
    }
    this.loadProductList();
  }

  //closing add product modal
  cancelForm() {
    this.productForm.reset();
    this.uploadFileElement.nativeElement.value = "";
    this.showAddForm = false;
    this.ref.detectChanges();
  }
}
