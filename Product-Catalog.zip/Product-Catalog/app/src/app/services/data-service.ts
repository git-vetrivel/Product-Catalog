import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn:'root'
})
export class DataService{
     ServerUrl="http://192.168.43.87:8100/";
    //function for handling api request and response
     processRequest(endpoint:string,reqData:any):Promise<any>{
         return new Promise((resolve)=>{
             this.http.post(this.ServerUrl+endpoint,reqData).toPromise().then((result:any)=>{
                // console.log("result============",result);
                resolve({response:true,result});                
             }).catch((error)=>{
                 console.log("error=====",error);
             });
         })
     }
}